﻿// JavaScript Document

$(function() {
    //$("header a.join").attr("href", "mailto:partner@1000zhu.com");
    //$("span.mail").html("partner@1000zhu.com");
});