var after = '';
var InterValObj;
//timer变量，控制时间      
var count = 60;
//间隔函数，1秒执行      
var curCount = 60;
//当前剩余秒数        
var exp = new Date();
var time;
var Islog = false;//设定一个全局参数判断用户有无登录
var sessionId;
time = exp.getTime();

//获取cookie值          
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) return unescape(arr[2]); else return null;
}

//这是有设定过期时间的使用示例：               //s20是代表20秒               //h是指小时，如12小时则是：h12 
//d是天数，30天则：d30               //设置cookie          
function setCookie(name, value, time) {
    var strsec = getsec(time);
    var exp = new Date();
    exp.setTime(exp.getTime() + strsec * 1);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toUTCString();
}

function getsec(str) {
    var str1 = str.substring(1, str.length) * 1;
    var str2 = str.substring(0, 1);
    if (str2 == "s") {
        return str1 * 1000;
    } else if (str2 == "h") {
        return str1 * 60 * 60 * 1000;
    } else if (str2 == "d") {
        return str1 * 24 * 60 * 60 * 1000;
    }
}

function sendCode(can) {
    switch (can) {
        case 1://发送登录验证码
            sendMessage('#log_yzm', '#phone');
            break;
        case 2://发送注册验证码
            sendMessage('#getting', '#sign_tel');
            break;
        case 3://发送忘记密码的验证码
            sendMessage('#forget_getting', '#forget_tel');
            break;
        case 4:
            //TODO 获取个人中心的数据  然后发送验证码
            trySend('#send_old_tel_code', '15197207958');
            break;
    }

}

function sendMessage(btn_nm, phone) {//格式'#id'
    if (checkNull($(phone).val())) {
        return false;
    }
    if (getCookie('after') > time && document.cookie.indexOf('after') != -1) {
        console.log(getCookie('after'));
        console.log(document.cookie.indexOf('after'));
        alert("请不要在60秒内重复获取验证码");
    }

    trySend(btn_nm, $(phone).val());//调用一次
}

function trySend(btn, phoneVal) {
    if (getCookie('after') < time || document.cookie.indexOf('after') == -1 || getCookie('after') == null
    ) {
        //测试时先注释掉ajax请求代码，否则会不成  
        var url = "/user/sendSms?phone=" + phoneVal;
        var sendTp = "GET";
        var s = send(url, "", sendTp);
        if (!s) {
            return false
        }
        setCookie("after", time + 60 * 1000, "s60");
        setCookie("phone", phoneVal, "s60");
        curCount = count;
        $(btn).attr("disabled", "true");
        $(btn).val(curCount + "s");
        //设置button效果，开始计时   
        InterValObj = window.setInterval(function () {
            SetRemainTime(btn);
        }, 1000);//启动计时器，1秒执行一次 
    }
}

//timer处理函数  
function SetRemainTime(btn) {
    if (curCount == 0) {
        window.clearInterval(InterValObj);
        //停止计时器  
        $(btn).removeAttr("disabled");//启用按钮          
        $(btn).val("获取验证码");
        //清除验证码。如果不清除，过时间后，输入收到的验证码依然有效   
        code = "";
        curCount--;
    } else {
        curCount--;
        $(btn).val(curCount + "s");
    }
}


function checkpwd(pwd, repwd) {
    if (checkNull(pwd) || checkNull(repwd)) {
        return false
    }
    if (pwd == repwd) {
        return true;
    }
    alert("两次密码输入密码不一致!");
    return false;
}

//注册---二次密码验证
function checkrepassword() {
    var password = document.getElementById("sign_pwd").value;
    var repass = document.getElementById("sign_repwd").value;
    if (password == null || repass == null || repass == "") {
        return false;
    }
    if (password != repass) {
        alert("两次密码输入密码不一致!")
        return false;
    }
    return true;
}

function check() {
    if (checkrepassword()) {
        return true;
    }
    else {
        return false;
    }
}

function checkNull(can) {
    if (can != null && can != "") {
        return false;
    }
    return true;
}

function send(url, jsonStr, sendTp) {
    var jsonArrayFinal = JSON.stringify(jsonStr);//string类型
    console.log(jsonArrayFinal);
    var recode = "这是recode值,为了区分我这样写";
    var url_head = "http://robot.52trip.vip:8081";//  /robot
    if (sendTp == "GET") {
        console.log(sendTp);
        $.ajax({
            type: sendTp,
            url: url_head + url,
            async: false,//默认异步,在这里改为同步
            //data:jsonArrayFinal
            // contentType: "application/json",//get请求的时候这个不能要 正确返回的时候就是{"data":"","status":200}
            success: function (data) {
                if (data.status == 200) {
                    recode = true;
                } else {
                    alert(data.data);
                    recode = false;
                }
                var id = data.data.id;
                if (id) {
                    sessionId = id;
                    setCookie("sid", sessionId, "h1");
                }
            },
            error: function (xhr, status, errMsg) {
                alert("操作失败!");
                recode = false;
            }
        });
    } else {
        $.ajax({
            type: sendTp,
            url: url_head + url,
            async: false,//默认异步,在这里改为同步
            data: jsonArrayFinal,
            contentType: "application/json",
            success: function (data) {
                if (data.status == 200) {
                    alert("操作成功!");
                    recode = true;
                } else {
                    alert(data.data);
                    recode = false;
                }
                var id = data.data.id;
                if (id) {
                    sessionId = id;
                    setCookie("sid", sessionId, "h1");
                }
            },
            error: function (xhr, status, errMsg) {
                alert("操作失败!");
                recode = false;
            }
        });
    }
    console.log(recode);
    return recode;
}

//点击登录
function clickLog() {
    var phone, pwd, yzm;
    phone = document.getElementById("phone").value;
    pwd = document.getElementById("pwd").value;
    yzm = document.getElementById("log_code").value;
    if (checkNull(phone) || checkNull(pwd) || checkNull(yzm)) return false;
    if (!checkPartton(phone, 1)) return false;
    //var url = "http://www.52trip.vip/robot/user/login";TODO
    var url = "/user/login";
    var jsonStr = {"phone": phone, "password": pwd, "sms": yzm};
    Islog = send(url, jsonStr, "POST");
    if (Islog) {
        setCookie("Islog", Islog, "h1");
        //登录成功
        //window.open("//http://www.52trip.vip/robot/user/queryInfo?"+sessionId);
        var s = send("/user/queryInfo?" + sessionId, '', "GET");
        if (s) {
            LoginOrNot(Islog);
        }
    }
    return true;
}

//点击注册
function clickReg() {
    if (!check()) {
        return false;
    }
    var tel, pwd, repwd, yzm, rec_tel
    tel = document.getElementById("sign_tel").value;
    pwd = document.getElementById("sign_pwd").value;
    repwd = document.getElementById("sign_repwd").value;
    yzm = document.getElementById("mobile").value;
    rec_tel = document.getElementById("recommender_tel").value;
    if (checkNull(tel) || checkNull(yzm)) {
        return false;
    }
    if (!checkPartton(tel, 1) || !checkPartton(pwd, 2)) return false;
    var jsonStr = {
        "phone": tel,
        "password": pwd,
        "sms": yzm,
    };
    var url = "/user/create";
    if (!checkNull(rec_tel)) {
        if (!checkPartton(rec_tel, 1)) {
            return false
        }
        //给json对象添加新的属性并赋值
        jsonStr.recphone = rec_tel;
    }
    var s = send(url, jsonStr, "POST");
    if (s) {
        cambiar_login();
    }

}

checkIsLog();

function checkIsLog() {
    //检查是否登录
    if (getCookie('Islog') == null) {
        LoginOrNot(false);
    }
    else {
        Islog = getCookie('Islog');
        if (getCookie('sid')) {
            var s = send("/user/queryInfo?" + sessionId, '', "GET");
            if (s) {
                LoginOrNot(Islog);
            }
            else {
                LoginOrNot(false);
            }
        }
    }
}





